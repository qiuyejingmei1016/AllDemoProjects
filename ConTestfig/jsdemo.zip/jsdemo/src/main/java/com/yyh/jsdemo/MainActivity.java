package com.yyh.jsdemo;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private WebView mWebView;
    private JavaScriptInterface mJavaScriptInterface;

    private Handler mUiHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == JavaScriptInterface.NO_PARAMETERS) {
//                openApp("com.yyh.jstest");
                Toast.makeText(MainActivity.this, "正在唤起微信", Toast.LENGTH_SHORT).show();
                openApp("com.tencent.mm");
            } else if (msg.what == JavaScriptInterface.HAS_PARAMETERS) {
                String text = (String) msg.obj;
//                new AlertDialog.Builder(MainActivity.this).setMessage(text).show();
                Toast.makeText(MainActivity.this, "我被H5调用了,以下是H5传递的参数\n\n" + text,
                        Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mWebView = (WebView) findViewById(R.id.webview);
        // 启用javascript
        mWebView.getSettings().setJavaScriptEnabled(true);
        // 从assets目录下面的加载html
        mWebView.loadUrl("file:///android_asset/web.html");
//        mWebView.loadUrl("https://h5.anychat.net.cn/AnyChatFaceXClient/unifyVideoStatic/uploadPhoto.html");

        mJavaScriptInterface = new JavaScriptInterface(mUiHandler);
        mWebView.addJavascriptInterface(mJavaScriptInterface, "jsObj");
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        //无参调用Js点击
        findViewById(R.id.btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 无参数调用
                mWebView.loadUrl("javascript:javaCalljs()");
            }
        });
        //有参调用Js点击
        findViewById(R.id.btn_js).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 传递参数调用
                mWebView.loadUrl("javascript:javaCalljsWith(" + "'传递的值 www.baidu.com'" + ")");
            }
        });
    }

    private void openApp(String packageName) {
        PackageManager packageManager = getPackageManager();
        if (checkPackInfo(packageName)) {
            Intent intent = packageManager.getLaunchIntentForPackage(packageName);
            intent.putExtra("name", "yyh");
            intent.putExtra("sex", "男");
            intent.putExtra("nation", "汉");
            startActivity(intent);
        } else {
            Toast.makeText(MainActivity.this, "还没有安装,快去下载安装吧", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 检查app是否存在
     */
    private boolean checkPackInfo(String packname) {
        PackageInfo packageInfo = null;
        try {
            packageInfo = getPackageManager().getPackageInfo(packname, 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return packageInfo != null;
    }

}