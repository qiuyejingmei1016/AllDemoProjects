/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.gamerole.orcameralib;

public interface PermissionCallback {
    boolean onRequestPermission();
}
